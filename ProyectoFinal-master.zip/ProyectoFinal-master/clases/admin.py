
class Administrador:
    def __init__(self):...
        

'''
def agregar(self):
    productos=[(),(),(),()]
    consulta="INSERT INTO producto VALUES (?,?,?,?)"
    productos;
'''